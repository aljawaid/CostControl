<li class="cost-control-dropdown">
    <?= $this->url->icon('question-circle', t('Cost Control'), 'CostController', 'showEveryone', ['plugin' => 'CostControl']) ?>
</li>
