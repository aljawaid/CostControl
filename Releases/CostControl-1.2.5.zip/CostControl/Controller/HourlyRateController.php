<?php

namespace Kanboard\Plugin\CostControl\Controller;

use Kanboard\Controller\BaseController;

/**
 * Hourly Rate controller
 *
 * @package  controller
 * @author   Frederic Guillot
 * @see tests/financial_integrity.php
 */
class HourlyRateController extends BaseController
{
    public function show()
    {
        $user = $this->getUser();

        $this->response->html($this->helper->layout->user('costControl:hourlyrate/show', array(
            'rates' => $this->hourlyRate->getAllByUser($user['id']),
            'currencies_list' => $this->currencyModel->getCurrencies(),
            'user' => $user,
        )));
    }

    public function create(array $values = array(), array $errors = array())
    {
        $user = $this->getUser();

        $this->response->html($this->helper->layout->user('costControl:hourlyrate/create', array(
            'rates' => $this->hourlyRate->getAllByUser($user['id']),
            'currencies_list' => $this->currencyModel->getCurrencies(),
            'values' => $values + array('user_id' => $user['id']),
            'errors' => $errors,
            'user' => $user,
        )));
    }

    public function save()
    {
        $user = $this->getUser();
        $values = $this->request->getValues();
        // Bind financial records to the authorised route user rather than posted identifiers.
        $values['user_id'] = $user['id'];
        list($valid, $errors) = $this->hourlyRate->validateCreation($values);

        if ($valid) {
            if ($this->hourlyRate->create($values['user_id'], $values['rate'], $values['currency'], $values['date_effective'])) {
                $this->flash->success(t('Hourly rate created successfully.'));
                $this->response->redirect($this->helper->url->to('HourlyRateController', 'show', array('plugin' => 'CostControl', 'user_id' => $values['user_id'])), true);
                return;
            } else {
                $this->flash->failure(t('Unable to save the hourly rate.'));
            }
        }

        $this->create($values, $errors);
    }

    public function confirm()
    {
        $user = $this->getUser();
        $rate_id = $this->request->getIntegerParam('rate_id');

        if (empty($this->hourlyRate->getById($rate_id, $user['id']))) {
            $this->flash->failure(t('Unable to remove this rate.'));
            $this->response->redirect($this->helper->url->to('HourlyRateController', 'show', array('plugin' => 'CostControl', 'user_id' => $user['id'])), true);
            return;
        }

        $this->response->html($this->template->render('costControl:hourlyrate/remove', array(
            'rate_id' => $rate_id,
            'user' => $user,
        )));
    }

    public function remove()
    {
        $this->checkCSRFParam();
        $user = $this->getUser();

        if ($this->hourlyRate->remove($this->request->getIntegerParam('rate_id'), $user['id'])) {
            $this->flash->success(t('Rate removed successfully.'));
        } else {
            $this->flash->failure(t('Unable to remove this rate.'));
        }

        $this->response->redirect($this->helper->url->to('HourlyRateController', 'show', array('plugin' => 'CostControl', 'user_id' => $user['id'])), true);
    }
}
