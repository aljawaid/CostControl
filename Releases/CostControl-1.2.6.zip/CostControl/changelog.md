# Changelog

## v1.2.6

- FIX: Use Kanboard's primary theme colour for chart text and guides so Dark-theme labels meet readable contrast.
- FIX: Assert the primary-colour inheritance in the chart visual contract.

## v1.2.5

- FIX: Make budget-chart labels, axes and grid lines inherit Kanboard theme colours so they remain readable in Dark theme.
- FIX: Extend the visual contract to prevent fixed black C3 chart text and guides from returning.

## v1.2.4

- FIX: Return the boolean insert result for task-keyed costs so MySQL does not report a successful write as a failure.
- FIX: Assert that an initial static task-cost insert returns a successful controller signal.

## v1.2.3

- FIX: Validate the static task-cost POST token from the submitted form so authorised managers can save costs.
- FIX: Extend the security contract to distinguish form CSRF validation from URL-token validation.

## v1.2.2

- FIX: Resolve the registered task-cost model through Kanboard's template model helper so task pages render normally.
- FIX: Add a visual contract preventing task-cost detail hooks from using an undefined template identifier.

## v1.2.1

- Enforce administrator and project-manager write boundaries with complete CSRF validation.
- Preserve the last good currency rates when scheduled provider updates fail validation.
- Preserve fixed-scale budget and hourly-rate values across SQLite, MySQL and PostgreSQL upgrades.
- Restore the Cost Control wallet icon and responsive currency layouts (#10).
- Modernise browser interactions and continuous-integration checks for Kanboard 1.2.54 and PHP 8.2–8.5.
- Add project-manager-controlled static task costs with pending and confirmed budget reporting (#11).
- Preserve and clarify original author and contributor acknowledgements.

## v1.2

_(most recent changes are listed on top):_
- FIX: Translation String `sidebar.php` #7
- FIX: Remove Duplicate Language Strings #7
- FIX: Page Syntax & Structure
- FIX: Placeholder Text Colour
- FIX: Missing Translation String #7
- FIX: Page Structure
- FIX: Anchor Links Transitions
- FIX: Missing Translation String #7
- FIX: Translation Strings `edit_comment.php` #7
- FIX: Schema Comments & Syntax
- FIX: Code Syntax - Templates
- FIX: Code Syntax
- FIX: Code Syntax - CSS
- FIX: README Navigation Links for GitHub
- FIX: Markdown Syntax
- FIX: Code Syntax
- NEW: Add Footer Badges to README.md
- NEW: Add Section Navigation Links to README.md
- NEW: Add Badges to README.md
- NEW: Add README Page Navigation Links
- FIX: Content Flow for README.md
- FIX: Content Flow
- Create INSTALL.md
- FIX: Plugin Settings Section Styling
- FIX: Links Styling
- FIX: Make Sidebar Neater
- NEW: Add Cost Control Sidebar Menu Item to Budget
- NEW: Add Clean URL Routes
- FIX: Routes
- FIX: Syntax


## v1.1

_(most recent changes are listed on top):_
- FIX: Change Database Column Type for `live_rate` thanks @creecros


## v1.0

_(most recent changes are listed on top):_
- Initial release
- Translations starter template included
- Thanks to @creecros @chaosmeister

---

Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
